# InternShield Web App

React + Vite frontend for InternShield AI platform.

## Setup

1. Install dependencies: `npm install`
2. Create `.env.local` file with Firebase configuration
3. Run development server: `npm run dev`
4. Build for production: `npm run build`

## Environment Variables

Create `.env.local`:
```
VITE_API_URL=http://localhost:5000
VITE_FIREBASE_API_KEY=your_firebase_key
VITE_FIREBASE_AUTH_DOMAIN=your_auth_domain
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_storage_bucket
VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
VITE_FIREBASE_APP_ID=your_app_id
```

## Features

- Google Authentication
- Internship analysis
- Company search
- Reports and reviews
- Dashboard with analytics
