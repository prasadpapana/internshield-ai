import React, { useState, useEffect } from 'react'
import TrustScoreCard from '../components/TrustScoreCard'
import { apiClient } from '../services/api'

export default function DashboardPage() {
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchDashboardStats = async () => {
      try {
        const response = await apiClient.get('/dashboard/stats')
        setStats(response.data.stats)
      } catch (err) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    fetchDashboardStats()
  }, [])

  if (loading) return <div className="p-8 text-center">Loading dashboard...</div>
  if (error) return <div className="p-8 text-center text-red-600">Error: {error}</div>

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-8">Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-gray-600 text-sm font-semibold mb-2">Total Analyses</div>
          <div className="text-3xl font-bold">{stats?.totalAnalyses || 0}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-gray-600 text-sm font-semibold mb-2">Total Reports</div>
          <div className="text-3xl font-bold">{stats?.totalReports || 0}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-gray-600 text-sm font-semibold mb-2">Total Reviews</div>
          <div className="text-3xl font-bold">{stats?.totalReviews || 0}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-gray-600 text-sm font-semibold mb-2">Avg. Trust Score</div>
          <div className="text-3xl font-bold">{Math.round(stats?.averageTrustScore || 0)}</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <TrustScoreCard score={stats?.riskLevelDistribution?.safe || 0} riskLevel="SAFE" />
        <TrustScoreCard score={stats?.riskLevelDistribution?.mediumRisk || 0} riskLevel="MEDIUM_RISK" />
        <TrustScoreCard score={stats?.riskLevelDistribution?.highRisk || 0} riskLevel="HIGH_RISK" />
      </div>
    </div>
  )
}
