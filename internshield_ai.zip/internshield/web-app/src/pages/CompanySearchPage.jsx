export default function CompanySearchPage() {
  return <div className="p-8"><h1 className="text-3xl font-bold">Company Search</h1></div>
}
