export default function ReportsPage() {
  return <div className="p-8"><h1 className="text-3xl font-bold">Reports</h1></div>
}
