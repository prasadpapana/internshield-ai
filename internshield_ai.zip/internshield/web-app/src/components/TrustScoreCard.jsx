import React from 'react'

export default function TrustScoreCard({ score, riskLevel }) {
  const getColor = (level) => {
    switch (level) {
      case 'SAFE':
        return { bg: 'bg-green-100', text: 'text-green-800', border: 'border-green-300' }
      case 'MEDIUM_RISK':
        return { bg: 'bg-yellow-100', text: 'text-yellow-800', border: 'border-yellow-300' }
      case 'HIGH_RISK':
        return { bg: 'bg-red-100', text: 'text-red-800', border: 'border-red-300' }
      default:
        return { bg: 'bg-gray-100', text: 'text-gray-800', border: 'border-gray-300' }
    }
  }

  const colors = getColor(riskLevel)

  return (
    <div className={`${colors.bg} ${colors.border} border rounded-lg p-6 text-center`}>
      <div className="text-5xl font-bold mb-2">{score}</div>
      <div className={`${colors.text} text-lg font-semibold mb-2`}>{riskLevel}</div>
      <div className="w-full bg-gray-300 rounded-full h-2">
        <div
          className={`h-2 rounded-full ${
            riskLevel === 'SAFE' ? 'bg-green-500' :
            riskLevel === 'MEDIUM_RISK' ? 'bg-yellow-500' :
            'bg-red-500'
          }`}
          style={{ width: `${score}%` }}
        ></div>
      </div>
    </div>
  )
}
