import React from 'react'
import { Link, useLocation } from 'react-router-dom'

const navItems = [
  { path: '/dashboard', label: 'Dashboard', icon: '📊' },
  { path: '/analyze', label: 'Analyze', icon: '🔍' },
  { path: '/company-search', label: 'Search', icon: '🏢' },
  { path: '/reports', label: 'Reports', icon: '📝' },
  { path: '/reviews', label: 'Reviews', icon: '⭐' },
  { path: '/analytics', label: 'Analytics', icon: '📈' }
]

export default function Sidebar() {
  const location = useLocation()

  return (
    <aside className="w-64 bg-gray-900 text-white p-6 hidden md:block">
      <div className="mb-8">
        <h2 className="text-2xl font-bold">InternShield</h2>
        <p className="text-sm text-gray-400 mt-1">AI Verification Platform</p>
      </div>

      <nav className="space-y-2">
        {navItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`block px-4 py-3 rounded-lg transition ${
              location.pathname === item.path
                ? 'bg-blue-600 text-white'
                : 'text-gray-300 hover:bg-gray-800'
            }`}
          >
            <span className="mr-3">{item.icon}</span>
            {item.label}
          </Link>
        ))}
      </nav>
    </aside>
  )
}
