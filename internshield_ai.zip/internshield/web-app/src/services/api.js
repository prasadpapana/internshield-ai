import axios from 'axios'
import { getAuth } from 'firebase/auth'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000'

const instance = axios.create({
  baseURL: API_URL,
  timeout: 10000
})

instance.interceptors.request.use(async (config) => {
  const auth = getAuth()
  const user = auth.currentUser

  if (user) {
    const token = await user.getIdToken()
    config.headers.Authorization = `Bearer ${token}`
  }

  return config
}, (error) => {
  return Promise.reject(error)
})

instance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      window.location.href = '/'
    }
    return Promise.reject(error)
  }
)

export const apiClient = instance
