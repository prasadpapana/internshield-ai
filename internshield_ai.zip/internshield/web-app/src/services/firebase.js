// Import the functions you need from the SDKs you need
import { initializeApp } from 'firebase/app'
import { getAnalytics } from 'firebase/analytics'
import { getAuth, signInWithPopup, GoogleAuthProvider, signOut } from 'firebase/auth'

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAt28tu_TMdtalC-wyoZzjNz0JYgGJUsHY",
  authDomain: "intern-ab1fb.firebaseapp.com",
  projectId: "intern-ab1fb",
  storageBucket: "intern-ab1fb.firebasestorage.app",
  messagingSenderId: "911032545787",
  appId: "1:911032545787:web:7b4b77cc6b9a24c1851b5e",
  measurementId: "G-9X6SQ99TJ9"
}

// Initialize Firebase
export const firebaseApp = initializeApp(firebaseConfig)
export const analytics = getAnalytics(firebaseApp)
export const auth = getAuth(firebaseApp)
export const googleProvider = new GoogleAuthProvider()

// Helper functions for auth flow
export const signInWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider)
    return result.user
  } catch (error) {
    console.error('Sign-in error:', error)
    throw error
  }
}

export const signOutUser = async () => {
  try {
    await signOut(auth)
  } catch (error) {
    console.error('Sign-out error:', error)
    throw error
  }
}

export const getIdToken = async () => {
  try {
    return await auth.currentUser?.getIdToken()
  } catch (error) {
    console.error('Get ID token error:', error)
    throw error
  }
}
