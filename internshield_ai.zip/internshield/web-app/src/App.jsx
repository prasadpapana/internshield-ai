import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './hooks/useAuth'
import Navbar from './components/Navbar'
import Sidebar from './components/Sidebar'

// Pages
import HomePage from './pages/HomePage'
import DashboardPage from './pages/DashboardPage'
import AnalysisPage from './pages/AnalysisPage'
import CompanySearchPage from './pages/CompanySearchPage'
import ReportsPage from './pages/ReportsPage'
import ReviewsPage from './pages/ReviewsPage'
import AnalyticsPage from './pages/AnalyticsPage'

export default function App() {
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading InternShield...</p>
        </div>
      </div>
    )
  }

  return (
    <Router>
      <div className="flex min-h-screen bg-gray-50">
        {user && <Sidebar />}
        <div className="flex-1 flex flex-col">
          <Navbar />
          <main className="flex-1 overflow-auto">
            <Routes>
              <Route path="/" element={user ? <Navigate to="/dashboard" /> : <HomePage />} />
              {user ? (
                <>
                  <Route path="/dashboard" element={<DashboardPage />} />
                  <Route path="/analyze" element={<AnalysisPage />} />
                  <Route path="/company-search" element={<CompanySearchPage />} />
                  <Route path="/reports" element={<ReportsPage />} />
                  <Route path="/reviews" element={<ReviewsPage />} />
                  <Route path="/analytics" element={<AnalyticsPage />} />
                </>
              ) : (
                <Route path="*" element={<Navigate to="/" />} />
              )}
            </Routes>
          </main>
        </div>
      </div>
    </Router>
  )
}
