$secret = 'C:\internshield\backend\intern-ab1fb-firebase-adminsdk-fbsvc-c306b552a8.json'
$zipPath = 'C:\internshield\internshield-ai-safe.zip'
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
$files = Get-ChildItem -Path 'C:\internshield' -Recurse -File | Where-Object { $_.FullName -ne $secret }
$paths = $files | Select-Object -ExpandProperty FullName
Compress-Archive -Path $paths -DestinationPath $zipPath -Force
Write-Output 'SAFE_ZIP_CREATED'