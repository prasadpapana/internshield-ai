# InternShield AI - Quick Reference

## 🚀 Project Overview

**InternShield AI** is a complete AI-powered internship verification platform consisting of:

| Component | Technology | Port | Purpose |
|-----------|-----------|------|---------|
| Backend API | Node.js + Express | 5000 | REST API with Grok AI integration |
| Frontend App | React + Vite | 5173 | Dashboard and analysis interface |
| Chrome Extension | Manifest V3 | N/A | Real-time internship detection |

## 📂 Directory Structure

```
internshield/
├── backend/                 # Express.js API
│   ├── src/
│   │   ├── routes/         # API endpoints
│   │   ├── controllers/    # Route logic
│   │   ├── services/       # Business logic (Grok, verification)
│   │   ├── middleware/     # Auth, validation, logging
│   │   ├── models/         # Data models
│   │   ├── utils/          # Helper functions
│   │   └── config/         # Configuration
│   └── package.json
├── web-app/                # React + Vite frontend
│   ├── src/
│   │   ├── pages/          # Page components
│   │   ├── components/     # Reusable components
│   │   ├── services/       # API client, Firebase
│   │   ├── hooks/          # Custom hooks
│   │   └── styles/         # Tailwind CSS
│   └── package.json
├── chrome-extension/       # Chrome Extension MV3
│   ├── src/
│   │   ├── popup/          # Extension UI
│   │   ├── content/        # Content scripts
│   │   ├── background/     # Service worker
│   │   └── styles/         # Extension styling
│   ├── manifest.json       # MV3 manifest
│   └── package.json
├── .github/               # GitHub config
├── package.json           # Root package.json
├── README.md              # Project documentation
├── SETUP.md               # Setup guide
└── .gitignore             # Git ignore rules
```

## 🔧 Quick Commands

```bash
# Install all dependencies
npm run setup

# Start backend (port 5000)
npm run dev:backend

# Start frontend (port 5173)
npm run dev:frontend

# Build for production
npm run build:backend
npm run build:frontend
npm run build:extension

# Check API health
curl http://localhost:5000/health
```

## 📡 API Endpoints

| Method | Endpoint | Auth | Purpose |
|--------|----------|------|---------|
| POST | `/api/auth/login` | No | User login |
| POST | `/api/auth/signup` | No | User registration |
| POST | `/api/analyze` | Yes | Analyze internship |
| POST | `/api/report` | Yes | Submit scam report |
| POST | `/api/review` | Yes | Submit review |
| GET | `/api/company/search/:name` | No | Search companies |
| GET | `/api/dashboard/stats` | Yes | Dashboard statistics |

## 🎯 Trust Score Calculation

```
Final Score = 
  (AI Analysis × 0.40) +
  (Domain Verification × 0.20) +
  (Website Verification × 0.10) +
  (LinkedIn Verification × 0.10) +
  (Community Reports × 0.10) +
  (Community Reviews × 0.10)

Risk Levels:
- 80-100: 🟢 SAFE
- 60-79: 🟡 MEDIUM RISK
- 0-59: 🔴 HIGH RISK
```

## 🔑 Key Features

### Web App
- ✅ Google authentication via Firebase
- ✅ Dashboard with analytics
- ✅ Real-time internship analysis
- ✅ Company search and verification
- ✅ Community reports and reviews
- ✅ Performance analytics

### Chrome Extension
- ✅ Auto-detection on job sites
- ✅ Real-time trust score display
- ✅ Quick report submission
- ✅ In-line company reviews
- ✅ Background analysis

### Backend
- ✅ Grok AI integration
- ✅ Domain verification
- ✅ Website reachability checks
- ✅ LinkedIn profile verification
- ✅ JWT authentication
- ✅ Rate limiting

## 🔐 Security Features

- ✅ JWT-based authentication
- ✅ Firebase ID token verification
- ✅ Input validation on all endpoints
- ✅ CORS protection
- ✅ Helmet.js security headers
- ✅ Rate limiting (100 req/15 min)
- ✅ Environment variable configuration

## 🌐 Environment Variables

### Backend (backend/.env)
```
PORT=5000
NODE_ENV=development
FRONTEND_URL=http://localhost:5173
FIREBASE_PROJECT_ID=...
GROK_API_KEY=...
JWT_SECRET=...
```

### Frontend (web-app/.env.local)
```
VITE_API_URL=http://localhost:5000
VITE_FIREBASE_API_KEY=...
VITE_FIREBASE_AUTH_DOMAIN=...
```

## 🛠️ Tech Stack Summary

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Vite, Tailwind CSS |
| Backend | Node.js, Express.js |
| Authentication | Firebase Google Auth |
| AI/Analysis | Grok API |
| Database | Google Sheets API |
| Extension | Manifest V3 JavaScript |
| Hosting | Vercel (frontend), Custom (backend) |

## 📱 Testing Internship Sites

Test the extension on these job listing sites:
- LinkedIn Jobs (linkedin.com/jobs)
- Indeed (indeed.com)
- Glassdoor (glassdoor.com)
- Internships.com
- ZipRecruiter (ziprecruiter.com)

## 🚨 Common Issues & Solutions

| Issue | Solution |
|-------|----------|
| Port 5000 in use | Kill process or use different port |
| Firebase error | Check credentials in .env |
| CORS error | Verify FRONTEND_URL matches |
| Extension not loading | Refresh at chrome://extensions |
| API 401 error | Ensure token is valid |

## 📖 Documentation Links

- [Full Setup Guide](./SETUP.md)
- [Backend Documentation](./backend/README.md)
- [Frontend Documentation](./web-app/README.md)
- [Extension Documentation](./chrome-extension/README.md)

## 🎯 Next Steps

1. Install dependencies: `npm run setup`
2. Configure environment files
3. Start development servers
4. Load Chrome extension
5. Test on job listing sites
6. Configure database integration
7. Deploy to production

## 📊 Project Statistics

- **Total Files**: 50+
- **Lines of Code**: 3,000+
- **Components**: 10+ (React)
- **API Routes**: 10+
- **Services**: 5+ (Business logic)
- **Middleware**: 4 (Auth, Logging, Validation, Error)

---

**Version**: 1.0.0
**Last Updated**: 2024
**Status**: ✅ Ready for Development
