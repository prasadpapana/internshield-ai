// Service Worker for InternShield Chrome Extension

const API_URL = 'http://localhost:5000'

// Listen for messages from popup or content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'ANALYZE_INTERNSHIP') {
    analyzeInternship(message.data, sendResponse)
  } else if (message.type === 'GET_CACHED_ANALYSIS') {
    getCachedAnalysis(message.data, sendResponse)
  }
})

// Listen for tab updates to detect internship pages
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete') {
    checkAndInjectContentScript(tab)
  }
})

async function analyzeInternship(data, sendResponse) {
  try {
    const response = await fetch(`${API_URL}/api/analyze`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${await getStoredToken()}`
      },
      body: JSON.stringify(data)
    })

    const result = await response.json()
    
    if (result.success) {
      // Cache the result
      chrome.storage.local.set({
        [`analysis_${data.website}`]: {
          data: result.analysis,
          timestamp: Date.now()
        }
      })
      sendResponse({ success: true, analysis: result.analysis })
    } else {
      sendResponse({ success: false, error: result.error })
    }
  } catch (error) {
    sendResponse({ success: false, error: error.message })
  }
}

async function getCachedAnalysis(website, sendResponse) {
  chrome.storage.local.get([`analysis_${website}`], (result) => {
    const cached = result[`analysis_${website}`]
    if (cached && Date.now() - cached.timestamp < 24 * 60 * 60 * 1000) {
      sendResponse({ success: true, analysis: cached.data })
    } else {
      sendResponse({ success: false, error: 'No cached analysis' })
    }
  })
}

function checkAndInjectContentScript(tab) {
  // Check if URL matches internship-related patterns
  const internshipPatterns = [
    'linkedin.com/jobs',
    'indeed.com',
    'glassdoor.com',
    'internships.com',
    'thebalancecareers.com',
    'ziprecruiter.com'
  ]

  const isInternshipPage = internshipPatterns.some(pattern => 
    tab.url.includes(pattern)
  )

  if (isInternshipPage) {
    chrome.tabs.sendMessage(tab.id, { type: 'PAGE_TYPE', isInternship: true })
      .catch(() => {
        // Content script might not be loaded yet
      })
  }
}

async function getStoredToken() {
  return new Promise((resolve) => {
    chrome.storage.local.get('auth_token', (result) => {
      resolve(result.auth_token || '')
    })
  })
}

// Listen for auth token updates
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'STORE_AUTH_TOKEN') {
    chrome.storage.local.set({ auth_token: message.token })
    sendResponse({ success: true })
  }
})
