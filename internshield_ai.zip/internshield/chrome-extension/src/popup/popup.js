// Popup script for InternShield Chrome Extension

const API_URL = 'http://localhost:5000'

// DOM Elements
const loginBtn = document.getElementById('login-btn')
const logoutBtn = document.getElementById('logout-btn')
const analyzeBtn = document.getElementById('analyze-btn')
const backBtn = document.getElementById('back-btn')
const companyInput = document.getElementById('company-input')
const titleInput = document.getElementById('title-input')
const websiteInput = document.getElementById('website-input')

const authSection = document.getElementById('auth-section')
const appSection = document.getElementById('app-section')
const analysisForm = document.getElementById('analysis-form')
const resultSection = document.getElementById('result-section')
const loadingSection = document.getElementById('loading')
const errorSection = document.getElementById('error-section')

// Initialize popup
document.addEventListener('DOMContentLoaded', () => {
  checkAuthStatus()
  attachEventListeners()
})

function attachEventListeners() {
  loginBtn.addEventListener('click', login)
  logoutBtn.addEventListener('click', logout)
  analyzeBtn.addEventListener('click', analyzeInternship)
  backBtn.addEventListener('click', backToForm)
}

function checkAuthStatus() {
  chrome.storage.local.get('auth_token', (result) => {
    if (result.auth_token) {
      showAppSection()
    } else {
      showAuthSection()
    }
  })
}

function showAuthSection() {
  authSection.style.display = 'block'
  appSection.style.display = 'none'
}

function showAppSection() {
  authSection.style.display = 'none'
  appSection.style.display = 'block'
  analysisForm.style.display = 'block'
  resultSection.style.display = 'none'
}

function login() {
  // In a real implementation, this would use the Firebase API
  // For now, show a simple token input
  const token = prompt('Enter your authentication token:')
  if (token) {
    chrome.storage.local.set({ auth_token: token })
    chrome.runtime.sendMessage({
      type: 'STORE_AUTH_TOKEN',
      token: token
    })
    showAppSection()
  }
}

function logout() {
  chrome.storage.local.remove('auth_token')
  showAuthSection()
}

async function analyzeInternship() {
  const company = companyInput.value.trim()
  const title = titleInput.value.trim()
  const website = websiteInput.value.trim()

  if (!company || !title || !website) {
    showError('Please fill in all fields')
    return
  }

  loadingSection.style.display = 'block'
  analysisForm.style.display = 'none'

  try {
    const token = await getStoredToken()
    const response = await fetch(`${API_URL}/api/analyze`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        companyName: company,
        internshipTitle: title,
        website: website
      })
    })

    const result = await response.json()

    if (result.success) {
      displayResult(result.analysis)
    } else {
      showError(result.error || 'Analysis failed')
    }
  } catch (error) {
    showError(error.message)
  } finally {
    loadingSection.style.display = 'none'
  }
}

function displayResult(analysis) {
  const scoreElement = document.querySelector('.score-value')
  const riskElement = document.querySelector('.risk-level')
  const summaryElement = document.getElementById('analysis-summary')

  scoreElement.textContent = analysis.trustScore
  riskElement.textContent = analysis.riskLevel

  summaryElement.innerHTML = `
    <p><strong>${analysis.summary}</strong></p>
    ${analysis.warnings ? `
      <div class="warnings">
        <h4>Warnings:</h4>
        <ul>
          ${analysis.warnings.map(w => `<li>${w}</li>`).join('')}
        </ul>
      </div>
    ` : ''}
  `

  analysisForm.style.display = 'none'
  resultSection.style.display = 'block'
}

function backToForm() {
  companyInput.value = ''
  titleInput.value = ''
  websiteInput.value = ''
  analysisForm.style.display = 'block'
  resultSection.style.display = 'none'
}

function showError(message) {
  errorSection.style.display = 'block'
  document.getElementById('error-message').textContent = message
  loadingSection.style.display = 'none'
  analysisForm.style.display = 'block'
}

function getStoredToken() {
  return new Promise((resolve) => {
    chrome.storage.local.get('auth_token', (result) => {
      resolve(result.auth_token || '')
    })
  })
}
