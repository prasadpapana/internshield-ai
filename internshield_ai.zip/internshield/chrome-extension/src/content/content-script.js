// Content Script for InternShield Extension

console.log('InternShield Content Script Loaded')

// Listen for messages from service worker
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'PAGE_TYPE') {
    detectInternshipContent()
  }
})

// Auto-detect internship content
function detectInternshipContent() {
  const internshipKeywords = [
    'internship', 'intern', 'co-op', 'graduate program',
    'analyst', 'associate', 'entry level', 'junior'
  ]

  const pageText = document.body.innerText.toLowerCase()
  const hasInternshipKeywords = internshipKeywords.some(keyword =>
    pageText.includes(keyword)
  )

  if (hasInternshipKeywords) {
    extractAndAnalyzeInternships()
  }
}

function extractAndAnalyzeInternships() {
  // Find job postings or internship listings
  const jobElements = document.querySelectorAll(
    '[data-job-id], [class*="job"], [class*="posting"], article'
  )

  jobElements.forEach((element) => {
    const titleElement = element.querySelector('h1, h2, h3, [class*="title"]')
    const companyElement = element.querySelector('[class*="company"], [class*="employer"]')
    const linkElement = element.querySelector('a[href*="job"]')

    if (titleElement && companyElement) {
      const title = titleElement.innerText
      const company = companyElement.innerText
      const link = linkElement?.href || window.location.href

      analyzeJob(title, company, link, element)
    }
  })
}

function analyzeJob(title, company, url, element) {
  chrome.runtime.sendMessage({
    type: 'ANALYZE_INTERNSHIP',
    data: {
      internshipTitle: title,
      companyName: company,
      website: extractDomain(url),
      sourceUrl: url
    }
  }, (response) => {
    if (response.success) {
      displayTrustScore(element, response.analysis)
    }
  })
}

function displayTrustScore(element, analysis) {
  const scoreCard = document.createElement('div')
  scoreCard.className = 'internshield-trust-score'
  scoreCard.innerHTML = `
    <div class="score-card ${analysis.riskLevel.toLowerCase()}">
      <div class="score-value">${analysis.trustScore}</div>
      <div class="risk-level">${analysis.riskLevel}</div>
    </div>
  `
  scoreCard.style.cssText = `
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 10px 15px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    z-index: 1000;
  `

  if (element.style.position === 'static') {
    element.style.position = 'relative'
  }

  element.appendChild(scoreCard)
}

function extractDomain(url) {
  try {
    return new URL(url).hostname
  } catch {
    return url
  }
}

// Auto-detect on page load
document.addEventListener('DOMContentLoaded', detectInternshipContent)

// Also run immediately in case DOM is already loaded
if (document.readyState === 'loading') {
  detectInternshipContent()
}
