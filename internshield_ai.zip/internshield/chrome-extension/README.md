# InternShield Chrome Extension

Chrome Extension (Manifest V3) for InternShield AI platform.

## Features

- 🎯 Auto-detection of internship pages
- ✅ Real-time trust score display
- 🚨 Report suspicious internships
- 👥 Community reviews integration
- 🤖 Automatic AI analysis

## Installation

1. Navigate to `chrome://extensions`
2. Enable "Developer mode" (top right)
3. Click "Load unpacked"
4. Select the `chrome-extension` folder

## Files Structure

- `manifest.json` - Extension configuration
- `src/background/service-worker.js` - Service worker (MV3 requirement)
- `src/content/content-script.js` - Content script for page injection
- `src/popup/` - Popup UI and logic
- `src/styles/` - Extension styling

## Configuration

Update the API_URL in service-worker.js and popup.js to match your backend.
