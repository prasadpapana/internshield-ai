# InternShield AI — Project Specification

## Project
- **Name:** InternShield AI
- **Version:** 1.0.0
- **Type:** Web app + Chrome extension
- **Description:** AI-powered internship verification platform

## Tech Stack
- **Frontend:** React, Vite, Tailwind CSS
- **Chrome Extension:** Manifest V3 (JavaScript)
- **Backend:** Node.js + Express
- **Auth:** Firebase Google Auth
- **Database:** Google Sheets API
- **AI:** Grok API
- **Hosting:** Vercel

## Modules & Features

- **Web App**
  - Google Login
  - Dashboard
  - Internship Analysis
  - Company Search
  - Reports
  - Reviews
  - Analytics

- **Chrome Extension**
  - Internship Detection
  - Trust Score Popup
  - Report Internship
  - Community Reviews
  - Auto Analysis

## High-level Workflow
1. User opens internship page or submits internship URL
2. Collect internship information
3. Send data to backend API
4. Run Grok AI analysis
5. Verify domain information
6. Verify company website
7. Verify LinkedIn company profile
8. Check community reports and reviews
9. Calculate trust score
10. Return final result

## Data Collected
- companyName, internshipTitle, description, website, recruiterName, recruiterEmail, salary, location

## Trust Score Weighting
- AI analysis: 40%
- Domain verification: 20%
- Website verification: 10%
- LinkedIn verification: 10%
- Community reports: 10%
- Community reviews: 10%

## Risk Levels
- **Safe:** 80–100
- **Medium Risk:** 60–79
- **High Risk:** 0–59

## Database Tables (Google Sheets)
- **Users:** `userId, name, email, createdAt`
- **Companies:** `companyName, website, trustScore, createdAt`
- **Reports:** `user, company, reason, date`
- **Reviews:** `user, company, rating, comment, date`

## API Endpoints
- `POST /api/auth/login` — login / issue JWT
- `POST /api/analyze` — submit internship for analysis
- `POST /api/report` — create a report
- `POST /api/review` — create a review
- `GET /api/company/:name` — search company
- `GET /api/dashboard` — user dashboard stats

## Security
- JWT issued by backend
- Firebase ID token verification
- Input validation, CORS, Helmet headers, rate limiting
- Use environment variables for secrets

## AI Prompt (Example)
- Role: Internship Scam Detection Expert
- Tasks: Detect scams, fake recruiters/companies, suspicious domains, unrealistic salaries, and generate a trust score.
- Example output:

```json
{
  "trustScore": 85,
  "riskLevel": "SAFE",
  "summary": "Company appears legitimate.",
  "warnings": ["No major issues found"]
}
```
