# InternShield AI - Complete Setup Guide

## 📋 Table of Contents

1. [Quick Start](#quick-start)
2. [Prerequisites](#prerequisites)
3. [Project Setup](#project-setup)
4. [Environment Configuration](#environment-configuration)
5. [Running the Application](#running-the-application)
6. [Chrome Extension Setup](#chrome-extension-setup)
7. [Development Workflow](#development-workflow)
8. [Troubleshooting](#troubleshooting)

## 🚀 Quick Start

```bash
# 1. Navigate to project directory
cd c:\internshield

# 2. Install all dependencies
npm run setup

# 3. Configure environment files
# - Create backend/.env (copy from backend/.env.example)
# - Create web-app/.env.local (copy from web-app/.env.example)

# 4. Start development servers
npm run dev:backend  # Terminal 1
npm run dev:frontend # Terminal 2
```

## 📦 Prerequisites

- **Node.js**: Version 18.0.0 or higher
- **npm**: Version 8.0.0 or higher
- **Git**: For version control
- **Chrome**: For testing the extension
- **Firebase Account**: For authentication
- **Grok API Key**: For AI analysis

## 🏗️ Project Setup

### Step 1: Clone/Extract Project

```bash
# Navigate to project directory
cd c:\internshield
```

### Step 2: Install Dependencies

```bash
# Install dependencies for all modules
npm run setup

# This runs:
# - npm install (root)
# - npm install --prefix backend
# - npm install --prefix web-app
```

### Step 3: Verify Installation

```bash
# Check Node.js version
node --version

# Check npm version
npm --version
```

## ⚙️ Environment Configuration

### Backend Configuration

1. **Create .env file**
   ```bash
   cp backend/.env.example backend/.env
   ```

2. **Fill in the values**
   ```env
   # Server
   PORT=5000
   NODE_ENV=development
   FRONTEND_URL=http://localhost:5173

   # Firebase
   FIREBASE_PROJECT_ID=your_project_id
   FIREBASE_PRIVATE_KEY=your_key
   # ... other Firebase vars

   # API Keys
   GROK_API_KEY=your_grok_key
   GOOGLE_SHEETS_API_KEY=your_sheets_key

   # JWT
   JWT_SECRET=your_secret_key
   ```

### Frontend Configuration

1. **Create .env.local file**
   ```bash
   cp web-app/.env.local.example web-app/.env.local
   ```

2. **Fill in the values**
   ```env
   # API
   VITE_API_URL=http://localhost:5000

   # Firebase
   VITE_FIREBASE_API_KEY=your_api_key
   VITE_FIREBASE_AUTH_DOMAIN=your_domain.firebaseapp.com
   # ... other Firebase vars
   ```

### Chrome Extension Configuration

Update API URLs in:
- `chrome-extension/src/background/service-worker.js` (line ~5)
- `chrome-extension/src/popup/popup.js` (line ~3)

## 🎯 Running the Application

### Option 1: Run All Services (Multiple Terminals)

```bash
# Terminal 1: Backend API
cd c:\internshield
npm run dev:backend

# Terminal 2: Frontend App
cd c:\internshield
npm run dev:frontend

# Chrome Extension is loaded manually (see below)
```

### Option 2: Individual Service Start

```bash
# Backend only
cd c:\internshield\backend
npm run dev

# Frontend only
cd c:\internshield\web-app
npm run dev
```

### Verify Services are Running

- **Backend**: Open http://localhost:5000/health
  - Should return: `{"status":"OK","timestamp":"..."}`

- **Frontend**: Open http://localhost:5173
  - Should show InternShield login page

## 🧩 Chrome Extension Setup

### Method 1: Load Unpacked Extension

1. Open Chrome and navigate to `chrome://extensions`
2. Enable "Developer mode" (toggle in top-right)
3. Click "Load unpacked"
4. Select the `c:\internshield\chrome-extension` folder
5. Extension should appear in Chrome toolbar

### Method 2: Pin Extension

1. Click the Extensions icon (puzzle piece) in toolbar
2. Find "InternShield AI"
3. Click the pin icon to pin it to toolbar

### Test the Extension

1. Visit a job site: linkedin.com/jobs, indeed.com, etc.
2. Extension popup should appear when viewing job listings
3. Click "Sign in with Google" to authenticate
4. Try analyzing an internship

## 💻 Development Workflow

### Adding a New API Route

1. **Create route file**: `backend/src/routes/newfeature.js`
2. **Create controller**: `backend/src/controllers/newfeatureController.js`
3. **Register route**: Import and add to `backend/src/index.js`

### Adding a New Page

1. **Create page component**: `web-app/src/pages/NewPage.jsx`
2. **Add route**: Register in `web-app/src/App.jsx`
3. **Update navigation**: Add to sidebar in `web-app/src/components/Sidebar.jsx`

### Modifying the Extension

1. Edit files in `chrome-extension/src/`
2. Go to `chrome://extensions`
3. Click the refresh icon on InternShield extension
4. Reload page to test changes

## 🐛 Troubleshooting

### Port Already in Use

```bash
# Find process using port 5000
netstat -ano | findstr :5000

# Kill the process
taskkill /PID <PID> /F
```

### Firebase Connection Error

```
Error: "Invalid Firebase credentials"
```

- Verify `backend/.env` has correct Firebase values
- Check Firebase project is active
- Ensure credentials have correct permissions

### Chrome Extension Not Loading

```
Error: "Service Worker registration failed"
```

- Check manifest.json syntax
- Verify all file paths are correct
- Clear extension cache: Go to chrome://extensions → Refresh
- Check Chrome DevTools console for errors

### API Request Failing

```bash
# Check backend is running
curl http://localhost:5000/health

# Check CORS settings in backend/src/index.js
# Verify FRONTEND_URL matches your frontend URL
```

### Database Connection Issues

- Verify Google Sheets API credentials
- Check API quotas aren't exceeded
- Ensure sheets exist with proper names

## 📝 Development Commands

```bash
# Build for production
npm run build:backend
npm run build:frontend
npm run build:extension

# Start in production mode
npm start --prefix backend

# Run tests
npm test --prefix backend
npm test --prefix web-app

# Type checking
npm run type-check --prefix web-app

# Linting
npm run lint
```

## 🔗 Useful Links

- [Firebase Console](https://console.firebase.google.com)
- [Grok API Docs](https://docs.x.ai/docs)
- [React Documentation](https://react.dev)
- [Express.js Documentation](https://expressjs.com)
- [Chrome Extension Docs](https://developer.chrome.com/docs/extensions)

## 📞 Support

For issues or questions:
1. Check the troubleshooting section above
2. Review module-specific README files
3. Check browser console for errors
4. Review server logs

---

**Next Steps**:
1. ✅ Set up environment variables
2. ✅ Install dependencies
3. ✅ Start development servers
4. ✅ Load Chrome extension
5. ✅ Test the application
