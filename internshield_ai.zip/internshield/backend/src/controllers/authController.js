import jwt from 'jsonwebtoken';
import { verifyFirebaseToken } from '../config/firebase.js';

export const loginUser = async (req, res) => {
  try {
    const { email, displayName, photoURL, firebaseToken } = req.body;

    if (!email || !firebaseToken) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Verify Firebase token using Firebase Admin SDK
    const decoded = await verifyFirebaseToken(firebaseToken);

    const userEmail = decoded.email || email;
    const userDisplayName = displayName || decoded.name || null;
    const userPhoto = photoURL || decoded.picture || null;

    const token = jwt.sign(
      { uid: decoded.uid, email: userEmail, displayName: userDisplayName },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      success: true,
      token,
      user: { email: userEmail, displayName: userDisplayName, photoURL: userPhoto }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const signupUser = async (req, res) => {
  try {
    const { email, displayName, photoURL, firebaseToken } = req.body;

    if (!email || !displayName || !firebaseToken) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Verify Firebase token for signup as well
    const decoded = await verifyFirebaseToken(firebaseToken);

    const userEmail = decoded.email || email;
    const userDisplayName = displayName || decoded.name || null;
    const userPhoto = photoURL || decoded.picture || null;

    // In a real app, save user to database
    const token = jwt.sign(
      { uid: decoded.uid, email: userEmail, displayName: userDisplayName },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.status(201).json({
      success: true,
      token,
      user: { email: userEmail, displayName: userDisplayName, photoURL: userPhoto }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const refreshToken = async (req, res) => {
  try {
    const { token } = req.body;

    if (!token) {
      return res.status(400).json({ error: 'Token required' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const newToken = jwt.sign(
      { email: decoded.email, displayName: decoded.displayName },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({ success: true, token: newToken });
  } catch (error) {
    res.status(401).json({ error: 'Invalid token' });
  }
};
