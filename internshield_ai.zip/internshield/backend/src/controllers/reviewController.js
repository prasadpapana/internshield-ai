export const createReview = async (req, res) => {
  try {
    const { companyId, rating, comment } = req.body;
    const userId = req.user.email;

    if (!companyId || !rating || rating < 1 || rating > 5) {
      return res.status(400).json({ error: 'Invalid review data' });
    }

    // In a real app, save to database
    const review = {
      userId,
      companyId,
      rating,
      comment,
      createdAt: new Date().toISOString()
    };

    res.status(201).json({
      success: true,
      message: 'Review submitted successfully',
      review
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const getReviews = async (req, res) => {
  try {
    const { companyId } = req.params;

    // In a real app, fetch from database
    const reviews = [];

    res.json({
      success: true,
      reviews,
      averageRating: 0
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
