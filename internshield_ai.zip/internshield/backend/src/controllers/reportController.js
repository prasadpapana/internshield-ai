export const createReport = async (req, res) => {
  try {
    const { companyId, company, reason, description } = req.body;
    const userId = req.user.email;

    if (!company || !reason) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // In a real app, save to database
    const report = {
      userId,
      companyId,
      company,
      reason,
      description,
      createdAt: new Date().toISOString()
    };

    res.status(201).json({
      success: true,
      message: 'Report submitted successfully',
      report
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const getReports = async (req, res) => {
  try {
    const userId = req.user.email;

    // In a real app, fetch from database
    const reports = [];

    res.json({
      success: true,
      reports
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
