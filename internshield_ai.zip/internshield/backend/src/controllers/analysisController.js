import { analyzeWithGrok } from '../services/grokService.js';
import { verifyDomain, verifyWebsite, verifyLinkedIn } from '../services/verificationService.js';
import { calculateTrustScore } from '../utils/trustScoreCalculator.js';

export const analyzeInternship = async (req, res) => {
  try {
    const {
      companyName,
      internshipTitle,
      description,
      website,
      recruiterName,
      recruiterEmail,
      salary,
      location
    } = req.body;

    // Run AI analysis with Grok
    const aiAnalysis = await analyzeWithGrok({
      companyName,
      internshipTitle,
      description,
      website,
      salary
    });

    // Run verification checks
    const [domainVerification, websiteVerification, linkedinVerification] = await Promise.all([
      verifyDomain(website),
      verifyWebsite(website),
      verifyLinkedIn(companyName)
    ]);

    // Calculate final trust score
    const trustScore = calculateTrustScore(
      aiAnalysis.trustScore,
      domainVerification.isVerified,
      websiteVerification.isActive,
      linkedinVerification.profileExists,
      0, // community reports (from database)
      4.5 // community reviews (from database)
    );

    res.json({
      success: true,
      analysis: {
        companyName,
        internshipTitle,
        trustScore,
        riskLevel: getRiskLevel(trustScore),
        aiAnalysis,
        verifications: {
          domain: domainVerification,
          website: websiteVerification,
          linkedin: linkedinVerification
        },
        summary: generateSummary(trustScore, aiAnalysis),
        warnings: generateWarnings(aiAnalysis, domainVerification, websiteVerification)
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getRiskLevel = (score) => {
  if (score >= 80) return 'SAFE';
  if (score >= 60) return 'MEDIUM_RISK';
  return 'HIGH_RISK';
};

const generateSummary = (score, analysis) => {
  if (score >= 80) return 'Company appears to be legitimate and trustworthy.';
  if (score >= 60) return 'Company has some concerns but may be legitimate. Verify details carefully.';
  return 'Company shows multiple red flags. Exercise caution.';
};

const generateWarnings = (analysis, domainVerification, websiteVerification) => {
  const warnings = [];
  
  if (analysis.warnings && analysis.warnings.length > 0) {
    warnings.push(...analysis.warnings);
  }
  
  if (!domainVerification.isVerified) {
    warnings.push('Domain could not be fully verified');
  }
  
  if (!websiteVerification.isActive) {
    warnings.push('Company website appears inactive or unreachable');
  }

  return warnings.length > 0 ? warnings : ['No major issues found'];
};
