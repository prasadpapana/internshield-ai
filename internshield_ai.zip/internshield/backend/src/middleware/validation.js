export const validateAnalysisInput = (req, res, next) => {
  const { companyName, internshipTitle, website, recruiterEmail, salary } = req.body;

  if (!companyName || !internshipTitle || !website) {
    return res.status(400).json({
      error: 'Missing required fields: companyName, internshipTitle, website'
    });
  }

  if (website && !/^https?:\/\/.+/.test(website)) {
    return res.status(400).json({
      error: 'Invalid website URL'
    });
  }

  next();
};
