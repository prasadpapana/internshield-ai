import admin from 'firebase-admin';
import path from 'path';
import fs from 'fs';

// Support two modes:
// 1) Service account JSON file specified by GOOGLE_APPLICATION_CREDENTIALS (recommended)
// 2) Inline env variables for service account (FIREBASE_PRIVATE_KEY etc.)

const serviceAccountPath = process.env.GOOGLE_APPLICATION_CREDENTIALS;

if (serviceAccountPath) {
  const resolvedPath = path.resolve(process.cwd(), serviceAccountPath);
  if (fs.existsSync(resolvedPath)) {
    const serviceAccount = JSON.parse(fs.readFileSync(resolvedPath, 'utf8'));
    if (!admin.apps.length) {
      admin.initializeApp({
        credential: admin.credential.cert(serviceAccount)
      });
    }
  } else {
    // If file not found, fallback to inline env vars below
    // Log a helpful message so developers can fix env
    // eslint-disable-next-line no-console
    console.warn(`Firebase service account file not found at ${resolvedPath}. Falling back to inline env vars.`);
  }
} else {
  // Fallback to inline service account values from env
  const firebaseConfig = {
    type: process.env.FIREBASE_TYPE,
    project_id: process.env.FIREBASE_PROJECT_ID,
    private_key_id: process.env.FIREBASE_PRIVATE_KEY_ID,
    private_key: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
    client_email: process.env.FIREBASE_CLIENT_EMAIL,
    client_id: process.env.FIREBASE_CLIENT_ID,
    auth_uri: process.env.FIREBASE_AUTH_URI,
    token_uri: process.env.FIREBASE_TOKEN_URI,
    auth_provider_x509_cert_url: process.env.FIREBASE_AUTH_PROVIDER_X509_CERT_URL,
    client_x509_cert_url: process.env.FIREBASE_CLIENT_X509_CERT_URL
  };

  if (!admin.apps.length) {
    admin.initializeApp({
      credential: admin.credential.cert(firebaseConfig)
    });
  }
}

export const auth = admin.auth();
export const firestore = admin.firestore();

export const verifyFirebaseToken = async (token) => {
  try {
    const decodedToken = await auth.verifyIdToken(token);
    return decodedToken;
  } catch (error) {
    throw new Error('Invalid Firebase token');
  }
};

export default admin;
