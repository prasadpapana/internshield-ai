import express from 'express';
import { createReview, getReviews } from '../controllers/reviewController.js';
import { verifyAuth } from '../middleware/auth.js';

const router = express.Router();

router.post('/', verifyAuth, createReview);
router.get('/:companyId', getReviews);

export default router;
