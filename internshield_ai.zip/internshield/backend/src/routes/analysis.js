import express from 'express';
import { analyzeInternship } from '../controllers/analysisController.js';
import { verifyAuth } from '../middleware/auth.js';
import { validateAnalysisInput } from '../middleware/validation.js';

const router = express.Router();

router.post('/', verifyAuth, validateAnalysisInput, analyzeInternship);

export default router;
