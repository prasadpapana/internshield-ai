import express from 'express';
import { searchCompany, getCompanyDetails } from '../controllers/companyController.js';

const router = express.Router();

router.get('/search/:name', searchCompany);
router.get('/:id', getCompanyDetails);

export default router;
