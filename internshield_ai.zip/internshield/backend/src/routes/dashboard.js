import express from 'express';
import { getDashboardStats } from '../controllers/dashboardController.js';
import { verifyAuth } from '../middleware/auth.js';

const router = express.Router();

router.get('/stats', verifyAuth, getDashboardStats);

export default router;
