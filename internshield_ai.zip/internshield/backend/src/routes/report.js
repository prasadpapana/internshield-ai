import express from 'express';
import { createReport, getReports } from '../controllers/reportController.js';
import { verifyAuth } from '../middleware/auth.js';

const router = express.Router();

router.post('/', verifyAuth, createReport);
router.get('/', verifyAuth, getReports);

export default router;
