import axios from 'axios';

const GROK_API_KEY = process.env.GROK_API_KEY;
const GROK_API_URL = 'https://api.x.ai/v1/chat/completions';

export const analyzeWithGrok = async (internshipData) => {
  try {
    const prompt = buildAnalysisPrompt(internshipData);

    const response = await axios.post(
      GROK_API_URL,
      {
        model: 'grok-beta',
        messages: [
          {
            role: 'system',
            content: 'You are an internship scam detection expert. Analyze internship opportunities and provide a trust score from 0-100.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.5
      },
      {
        headers: {
          'Authorization': `Bearer ${GROK_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    const analysis = parseGrokResponse(response.data.choices[0].message.content);
    return analysis;
  } catch (error) {
    console.error('Grok API Error:', error);
    // Return default analysis on error
    return {
      trustScore: 50,
      riskLevel: 'MEDIUM_RISK',
      warnings: ['Unable to complete full AI analysis'],
      summary: 'Analysis could not be completed. Please try again.'
    };
  }
};

const buildAnalysisPrompt = (data) => {
  return `
Analyze the following internship opportunity for potential scams:

Company Name: ${data.companyName}
Position: ${data.internshipTitle}
Website: ${data.website}
Salary: ${data.salary || 'Not specified'}
Description: ${data.description || 'Not provided'}

Please evaluate:
1. Legitimacy of the company
2. Realism of the salary
3. Common scam patterns
4. Domain and website legitimacy indicators

Provide your analysis in JSON format with:
- trustScore (0-100)
- riskLevel (SAFE, MEDIUM_RISK, HIGH_RISK)
- warnings (array of specific concerns)
- summary (brief assessment)
`;
};

const parseGrokResponse = (content) => {
  try {
    // Extract JSON from response
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
  } catch (e) {
    console.error('Error parsing Grok response:', e);
  }

  // Fallback parsing if JSON extraction fails
  const trustScore = extractNumber(content, 'trust score', 50);
  const riskLevel = content.includes('safe') ? 'SAFE' : 
                    content.includes('medium') ? 'MEDIUM_RISK' : 'HIGH_RISK';

  return {
    trustScore,
    riskLevel,
    warnings: ['Analysis interpretation may be incomplete'],
    summary: 'Analysis completed with limitations'
  };
};

const extractNumber = (text, keyword, defaultValue) => {
  const regex = new RegExp(keyword + '.*?(\\d+)', 'i');
  const match = text.match(regex);
  return match ? parseInt(match[1]) : defaultValue;
};
