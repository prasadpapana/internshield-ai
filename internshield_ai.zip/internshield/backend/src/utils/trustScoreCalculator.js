/**
 * Calculate trust score based on multiple verification factors
 * 
 * Weights:
 * - AI Analysis: 40%
 * - Domain Verification: 20%
 * - Website Verification: 10%
 * - LinkedIn Verification: 10%
 * - Community Reports: 10%
 * - Community Reviews: 10%
 */

export const calculateTrustScore = (
  aiScore,
  domainVerified,
  websiteActive,
  linkedinExists,
  communityReportScore,
  communityReviewScore
) => {
  const weights = {
    ai: 0.40,
    domain: 0.20,
    website: 0.10,
    linkedin: 0.10,
    communityReports: 0.10,
    communityReviews: 0.10
  };

  const scores = {
    ai: aiScore || 0,
    domain: domainVerified ? 100 : 30,
    website: websiteActive ? 100 : 20,
    linkedin: linkedinExists ? 100 : 40,
    communityReports: communityReportScore || 50,
    communityReviews: communityReviewScore * 20 || 50 // Convert 0-5 rating to 0-100
  };

  const finalScore = 
    (scores.ai * weights.ai) +
    (scores.domain * weights.domain) +
    (scores.website * weights.website) +
    (scores.linkedin * weights.linkedin) +
    (scores.communityReports * weights.communityReports) +
    (scores.communityReviews * weights.communityReviews);

  return Math.round(finalScore);
};

export const getRiskLevel = (score) => {
  if (score >= 80) return 'SAFE';
  if (score >= 60) return 'MEDIUM_RISK';
  return 'HIGH_RISK';
};

export const getScoreColor = (score) => {
  if (score >= 80) return 'green';
  if (score >= 60) return 'yellow';
  return 'red';
};
