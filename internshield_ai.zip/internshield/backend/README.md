# InternShield Backend API

Express.js API server for InternShield AI platform.

## Setup

1. Install dependencies: `npm install`
2. Create `.env` file with required variables
3. Run development server: `npm run dev`

## API Routes

- `POST /api/auth/login` - User login
- `POST /api/analyze` - Analyze internship
- `POST /api/report` - Create report
- `POST /api/review` - Create review
- `GET /api/company/:name` - Search company
- `GET /api/dashboard` - Get dashboard stats

## Environment Variables

See root README for required .env variables.
