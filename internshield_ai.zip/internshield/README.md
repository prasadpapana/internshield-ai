# InternShield AI

AI-powered internship verification platform that helps users identify scam internships and verify company legitimacy.

## 🎯 Project Overview

InternShield AI is a comprehensive platform consisting of:
- **Web Application**: React-based dashboard for internship analysis and company search
- **Chrome Extension**: Real-time internship detection and trust score verification
- **Backend API**: Express.js API with AI-powered analysis using Grok
- **Database**: Google Sheets API for data storage

## 📦 Project Structure

```
internshield/
├── backend/               # Express.js API server
│   ├── src/
│   │   ├── routes/       # API routes
│   │   ├── controllers/  # Route controllers
│   │   ├── middleware/   # Custom middleware
│   │   ├── services/     # Business logic
│   │   ├── models/       # Data models
│   │   ├── utils/        # Utility functions
│   │   └── config/       # Configuration files
│   └── package.json
├── web-app/              # React + Vite frontend
│   ├── src/
│   │   ├── components/   # React components
│   │   ├── pages/        # Page components
│   │   ├── services/     # API services
│   │   ├── context/      # React context
│   │   ├── hooks/        # Custom hooks
│   │   ├── styles/       # Tailwind CSS
│   │   └── App.jsx
│   └── package.json
├── chrome-extension/     # Chrome Extension (Manifest V3)
│   ├── src/
│   │   ├── popup/        # Popup UI
│   │   ├── content/      # Content scripts
│   │   ├── background/   # Service worker
│   │   └── styles/       # Extension styles
│   ├── manifest.json
│   └── package.json
└── README.md
```

## 🚀 Features

### Web Application
- 🔐 Google Login authentication
- 📊 Interactive dashboard with analytics
- 🔍 Internship analysis with AI verification
- 🏢 Company search and verification
- 📝 Generate detailed reports
- ⭐ Community reviews and ratings
- 📈 Performance analytics

### Chrome Extension
- 🎯 Auto-detection of internship pages
- ✅ Real-time trust score display
- 🚨 Report suspicious internships
- 👥 Community reviews integration
- 🤖 Automatic AI analysis

## 🛠 Tech Stack

### Frontend
- **Framework**: React 18
- **Build Tool**: Vite
- **Styling**: Tailwind CSS
- **HTTP Client**: Axios

### Backend
- **Runtime**: Node.js
- **Framework**: Express.js
- **Authentication**: Firebase Google Auth
- **Database**: Google Sheets API
- **AI**: Grok API

### Chrome Extension
- **Manifest**: V3
- **Language**: JavaScript

### Hosting
- **Platform**: Vercel

## 📋 API Routes

### Authentication
- `POST /api/auth/login` - Google login

### Analysis
- `POST /api/analyze` - Analyze internship

### Reports
- `POST /api/report` - Create report

### Reviews
- `POST /api/review` - Create review

### Companies
- `GET /api/company/:name` - Search company

### Dashboard
- `GET /api/dashboard` - Get user dashboard

## 🔒 Security Features

- JWT authentication
- Firebase verification
- Input validation
- CORS enabled
- Helmet.js headers
- Rate limiting
- Environment variables

## 📊 Trust Score Calculation

Trust Score is calculated from:
- **AI Analysis**: 40%
- **Domain Verification**: 20%
- **Website Verification**: 10%
- **LinkedIn Verification**: 10%
- **Community Reports**: 10%
- **Community Reviews**: 10%

### Risk Levels
- **🟢 SAFE**: 80-100
- **🟡 MEDIUM RISK**: 60-79
- **🔴 HIGH RISK**: 0-59

## 🗄️ Database Schema

### Users
- `userId` (string)
- `name` (string)
- `email` (string)
- `createdAt` (timestamp)

### Companies
- `companyName` (string)
- `website` (string)
- `trustScore` (number)
- `createdAt` (timestamp)

### Reports
- `user` (string)
- `company` (string)
- `reason` (string)
- `date` (timestamp)

### Reviews
- `user` (string)
- `company` (string)
- `rating` (number)
- `comment` (string)
- `date` (timestamp)

## 🤖 Grok AI Integration

The Grok AI analyzes internships to:
- Detect scam internships
- Identify fake recruiters
- Verify company legitimacy
- Detect suspicious domains
- Flag unrealistic salaries
- Generate trust scores

## 🔧 Installation & Setup

### Prerequisites
- Node.js >= 18.0.0
- npm or yarn
- Firebase project
- Grok API key
- Google Sheets API credentials

### Quick Start

1. **Clone the repository**
   ```bash
   cd c:\internshield
   ```

2. **Install dependencies**
   ```bash
   npm run setup
   ```

3. **Set up environment variables**
   - Backend: Create `.env` in `backend/`
   - Web App: Create `.env.local` in `web-app/`
   - Chrome Extension: Update config in `chrome-extension/src/config.js`

4. **Start development servers**
   ```bash
   npm run dev:backend
   npm run dev:frontend
   ```

5. **Build for production**
   ```bash
   npm run build:backend
   npm run build:frontend
   npm run build:extension
   ```

## 📝 Environment Variables

### Backend (.env)
```
PORT=5000
FIREBASE_API_KEY=your_firebase_key
FIREBASE_AUTH_DOMAIN=your_auth_domain
GROK_API_KEY=your_grok_key
GOOGLE_SHEETS_API_KEY=your_sheets_key
MONGODB_URI=your_database_url
JWT_SECRET=your_jwt_secret
NODE_ENV=development
```

### Web App (.env.local)
```
VITE_API_URL=http://localhost:5000
VITE_FIREBASE_API_KEY=your_firebase_key
VITE_FIREBASE_AUTH_DOMAIN=your_auth_domain
```

## 📖 Documentation

See individual README files in each module:
- [Backend Documentation](./backend/README.md)
- [Web App Documentation](./web-app/README.md)
- [Chrome Extension Documentation](./chrome-extension/README.md)

## 🤝 Contributing

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a pull request

## 📄 License

This project is licensed under the MIT License - see LICENSE file for details.

## 📞 Support

For support, email support@internshield.ai or open an issue on GitHub.

## 🔮 Roadmap

- [ ] Mobile application
- [ ] Advanced analytics dashboard
- [ ] Machine learning model fine-tuning
- [ ] Integration with LinkedIn API
- [ ] Real-time notifications
- [ ] Community forum
- [ ] Automated report generation
