# Copilot Instructions for InternShield AI

This is a comprehensive AI-powered internship verification platform with three main components.

## Project Overview

**InternShield AI** is a full-stack application designed to help users verify internship opportunities and identify potential scams through AI analysis, domain verification, and community feedback.

### Key Technologies

- **Frontend**: React 18 + Vite + Tailwind CSS
- **Backend**: Node.js + Express.js
- **Chrome Extension**: Manifest V3 JavaScript
- **Authentication**: Firebase Google Auth
- **AI**: Grok API for analysis
- **Database**: Google Sheets API
- **Hosting**: Vercel (frontend), custom server (backend)

## Project Structure

```
internshield/
├── backend/              # Express.js API server
├── web-app/             # React Vite application
├── chrome-extension/    # Chrome Extension (MV3)
└── .github/             # GitHub configuration
```

## Getting Started

### Prerequisites

- Node.js >= 18.0.0
- npm or yarn
- Firebase project setup
- Grok API key
- Google Sheets API credentials

### Installation

```bash
cd c:\internshield

# Install all dependencies
npm run setup
```

### Development

```bash
# Terminal 1: Start Backend API
npm run dev:backend

# Terminal 2: Start Frontend
npm run dev:frontend

# Terminal 3: Load Chrome Extension
# Go to chrome://extensions → Load unpacked → select chrome-extension folder
```

### Build for Production

```bash
npm run build:backend
npm run build:frontend
npm run build:extension
```

## Configuration

### Backend Setup

1. Create `backend/.env` from `backend/.env.example`
2. Fill in Firebase and Grok API credentials
3. Run: `npm run dev:backend`

### Frontend Setup

1. Create `web-app/.env.local` from `web-app/.env.example`
2. Configure Firebase credentials
3. Run: `npm run dev:frontend`

### Chrome Extension

1. Update API_URL in extension files if needed
2. Go to `chrome://extensions`
3. Enable Developer Mode
4. Click "Load unpacked" and select `chrome-extension` folder

## API Routes

### Authentication
- `POST /api/auth/login` - User login with Firebase token
- `POST /api/auth/signup` - User registration
- `POST /api/auth/refresh` - Refresh authentication token

### Internship Analysis
- `POST /api/analyze` - Analyze an internship (requires auth)

### Reports
- `POST /api/report` - Submit a scam report (requires auth)
- `GET /api/report` - Get user's reports (requires auth)

### Reviews
- `POST /api/review` - Submit a company review (requires auth)
- `GET /api/review/:companyId` - Get company reviews

### Company Search
- `GET /api/company/search/:name` - Search for company
- `GET /api/company/:id` - Get company details

### Dashboard
- `GET /api/dashboard/stats` - Get user dashboard stats (requires auth)

## Feature Implementation

### Web Application Features

1. **Google Login** - Firebase authentication
2. **Dashboard** - User analytics and statistics
3. **Internship Analysis** - AI-powered verification with trust score
4. **Company Search** - Search verified companies
5. **Reports** - Community-reported scams
6. **Reviews** - User reviews and ratings
7. **Analytics** - Performance metrics and insights

### Chrome Extension Features

1. **Internship Detection** - Auto-detect on job sites
2. **Trust Score Display** - Real-time verification
3. **Report Internship** - Quick reporting interface
4. **Community Reviews** - In-line company reviews
5. **Auto Analysis** - Automatic background analysis

## Trust Score Calculation

The trust score is calculated from multiple factors:

- **AI Analysis (40%)** - Grok AI evaluation
- **Domain Verification (20%)** - Domain age and legitimacy
- **Website Verification (10%)** - Website accessibility
- **LinkedIn Verification (10%)** - Company profile existence
- **Community Reports (10%)** - Reported scams count
- **Community Reviews (10%)** - Average user ratings

### Risk Levels

- 🟢 **SAFE**: 80-100
- 🟡 **MEDIUM RISK**: 60-79
- 🔴 **HIGH RISK**: 0-59

## Security

The platform implements:

- ✅ JWT authentication
- ✅ Firebase verification
- ✅ Input validation
- ✅ CORS protection
- ✅ Helmet.js headers
- ✅ Rate limiting
- ✅ Environment variables

## Database Schema

### Users Table
- userId
- name
- email
- createdAt

### Companies Table
- companyName
- website
- trustScore
- createdAt

### Reports Table
- user
- company
- reason
- date

### Reviews Table
- user
- company
- rating
- comment
- date

## Deployment

### Backend (Vercel/Heroku)
```bash
npm run build:backend
# Deploy to your server
```

### Frontend (Vercel)
```bash
npm run build:frontend
# Vercel auto-deploys from git
```

### Chrome Extension
1. Build the extension
2. Publish to Chrome Web Store

## Development Guidelines

### Coding Standards

- Use ES6+ modules
- Follow component-based architecture (React)
- Implement proper error handling
- Add input validation on all endpoints
- Use environment variables for configuration

### Testing

- Write tests for critical API routes
- Test authentication flows
- Verify trust score calculations
- Test Chrome extension content injection

### Code Organization

- Keep controllers focused
- Use services for business logic
- Middleware for cross-cutting concerns
- Utilities for helper functions

## Troubleshooting

### Common Issues

1. **API Connection Failed**
   - Check CORS settings in backend
   - Verify API_URL in frontend

2. **Firebase Auth Error**
   - Ensure Firebase credentials are correct
   - Check Firebase project configuration

3. **Chrome Extension Not Loading**
   - Verify manifest.json syntax
   - Check console for errors in chrome://extensions

4. **Trust Score Not Calculating**
   - Verify Grok API key
   - Check verification service endpoints

## Next Steps

- [ ] Implement database (Google Sheets or MongoDB)
- [ ] Add user profile management
- [ ] Build mobile application
- [ ] Enhance AI model
- [ ] Create admin dashboard
- [ ] Setup CI/CD pipeline
- [ ] Write comprehensive tests

## Support & Contribution

For issues or contributions, please refer to the documentation in each module's README.md file.

---

**Last Updated**: 2024
**Version**: 1.0.0
